#include "tinyanalyzor.h"
#include "globals.h"
#include <QApplication>

int lineno = 0;
FILE * source;
FILE * listing;
FILE * code;
int EchoSource = FALSE;
int TraceScan = FALSE;
int TraceParse = TRUE;
int TraceAnalyze = FALSE;
int TraceCode = FALSE;
int Error = FALSE;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TinyAnalyzor w;
    w.show();
    return a.exec();
}
