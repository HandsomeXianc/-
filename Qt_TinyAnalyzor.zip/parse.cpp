/****************************************************/
/* File: parse.c                                    */
/* The parser implementation for the TINY compiler  */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "util.h"
#include "scan.h"
#include "parse.h"

static TokenType token; /* holds current token */

/* function prototypes for recursive calls */
static TreeNode * stmt_sequence(void);
static TreeNode * statement(void);
static TreeNode * if_stmt(void);
static TreeNode * repeat_stmt(void);
static TreeNode * assign_stmt(void);
static TreeNode * read_stmt(void);
static TreeNode * write_stmt(void);
static TreeNode * exp(void);

static TreeNode* bor_exp(void);
static TreeNode* band_exp(void);
static TreeNode* bnot_exp(void);


static TreeNode * simple_exp(void);
static TreeNode * term(void);
static TreeNode * factor(void);
static TreeNode* for_stmt(void);
static TreeNode* pow_term(void);

//�������ʽ����
static TreeNode* reg(void);
static TreeNode* reg_or(void);
static TreeNode* reg_and(void);
static TreeNode* reg_base(void);




static void syntaxError(char * message)
{ fprintf(listing,"\n>>> ");
  fprintf(listing,"Syntax error at line %d: %s",lineno,message);
  Error = TRUE;
}

static void match(TokenType expected)
{ if (token == expected) token = getToken();
  else {
    syntaxError("unexpected token -> ");
    printToken(token,tokenString);
    fprintf(listing,"      ");
  }
}

TreeNode * stmt_sequence(void)
{ TreeNode * t = statement();
  TreeNode * p = t;
  while ((token!=ENDFILE) && (token!=END) &&
         (token!=ELSE) && (token!=UNTIL)&&(token != ENDDO))
  { TreeNode * q;
    match(SEMI);
    q = statement();
    if (q!=NULL) {
      if (t==NULL) t = p = q;
      else /* now p cannot be NULL either */
      { p->sibling = q;
        p = q;
      }
    }
  }
  return t;
}


//P394 
//lineno: 961
TreeNode * statement(void)
{ TreeNode * t = NULL;
  switch (token) {
    case IF : t = if_stmt(); break;
    case REPEAT : t = repeat_stmt(); break;
    case ID : t = assign_stmt(); break;
    case READ : t = read_stmt(); break;
    case WRITE : t = write_stmt(); break;
    case FOR:t = for_stmt(); break;
    default : syntaxError("unexpected token -> ");
              printToken(token,tokenString);
              token = getToken();
              break;
  } /* end case */
  return t;
}

//�µ�IF�﷨����
//TreeNode* if_stmt(void)
//{
//    TreeNode* t = newStmtNode(IfK);
//    match(IF);
//    match(LPAREN);
//    if (t != NULL) 
//        t->child[0] = exp();
//    match(RPAREN);
//    if (t != NULL) t->child[1] = stmt_sequence();
//    if (token == ELSE) {
//        match(ELSE);
//        if (t != NULL) t->child[2] = stmt_sequence();
//    }
//    match(END);
//    return t;
//}

//P394 
//lineno: 977
TreeNode * if_stmt(void)
{ TreeNode * t = newStmtNode(IfK);
  match(IF);
  if (t!=NULL) t->child[0] = exp();
  match(THEN);
  if (t!=NULL) t->child[1] = stmt_sequence();
  if (token==ELSE) {
    match(ELSE);
    if (t!=NULL) t->child[2] = stmt_sequence();
  }
  match(END);
  return t;
}

//������FOR�﷨����
TreeNode* for_stmt(void) {
    TreeNode* t = newStmtNode(ForK);
    match(FOR);
    if (t != NULL)t->child[0] = assign_stmt();
    if (token == TO) match(TO);else match(DOWNTO);
    if (t != NULL)t->child[1] = simple_exp();
    match(DO);
    if (t != NULL)t->child[2] = stmt_sequence();
    match(ENDDO);
    return t;
}


static TreeNode* pow_term(void) {
    TreeNode* t = factor();
    while (token == POW) {
        TreeNode* p = newExpNode(OpK);
        if (p != NULL)
        {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
            match(token);
            p->child[1] = factor();
        }
    }
    return t;
}
//P394 
//lineno:991
TreeNode * repeat_stmt(void)
{ TreeNode * t = newStmtNode(RepeatK);
  match(REPEAT);
  if (t!=NULL) t->child[0] = stmt_sequence();
  match(UNTIL);
  if (t!=NULL) t->child[1] = exp();
  return t;
}

TreeNode * assign_stmt(void)
{ TreeNode * t = newStmtNode(AssignK);
  if ((t!=NULL) && (token==ID))
    t->attr.name = copyString(tokenString);
  match(ID);
  if ((token == ASSIGN) || (token == PLUSEQ)){
      token == ASSIGN ? match(ASSIGN) : match(PLUSEQ);
      if (t != NULL) t->child[0] = exp();
  }
  else if (token == REGASSIGN) {
      TreeNode* p = newStmtNode(RegAssignK);
      if (p != NULL) p->attr.name = t->attr.name;
      t = p;
      match(REGASSIGN);
      if (t != NULL) t->child[0] = reg();
  }
  return t;
}

TreeNode * read_stmt(void)
{ TreeNode * t = newStmtNode(ReadK);
  match(READ);
  if ((t!=NULL) && (token==ID))
    t->attr.name = copyString(tokenString);
  match(ID);
  return t;
}

TreeNode * write_stmt(void)
{ TreeNode * t = newStmtNode(WriteK);
  match(WRITE);
  if (t!=NULL) t->child[0] = exp();
  return t;
}
//
//TreeNode * exp(void)
//{ TreeNode * t = simple_exp();
//  if ((token==LT)||(token==EQ)||(token == GT) ||(token ==GTEQ)||(token == LTEQ)||(token ==LTGT)) {
//    TreeNode * p = newExpNode(OpK);
//    if (p!=NULL) {
//      p->child[0] = t;
//      p->attr.op = token;
//      t = p;
//    }
//    match(token);
//    if (t!=NULL)
//      t->child[1] = simple_exp();
//  }
//  return t;
//}


TreeNode* exp(void)
{
    TreeNode* t = bor_exp();
    if (token == BOR)
    {
        TreeNode* p = newExpNode(OpK); // �½�����ʽ���
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
        }
        match(token);
        if (t != NULL)
            t->child[1] = bor_exp();
    }
    return t;
}

static TreeNode* bor_exp(void){
    TreeNode* t = band_exp();
    if (token == BAND)
    {
        TreeNode* p = newExpNode(OpK); // �½�����ʽ���
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
        }
        match(token);
        if (t != NULL)
            t->child[1] = band_exp();
    }
    return t;
}

static TreeNode* band_exp()
{ TreeNode * t = simple_exp();
  if ((token==LT)||(token==EQ)||(token == GT) ||(token ==GTEQ)||(token == LTEQ)||(token ==LTGT)) {
    TreeNode * p = newExpNode(OpK);
    if (p!=NULL) {
      p->child[0] = t;
      p->attr.op = token;
      t = p;
    }
    match(token);
    if (t!=NULL)
      t->child[1] = simple_exp();
  }
  return t;
}

static TreeNode* bnot_exp() {
    TreeNode* tail = NULL;
    if (token == BNOT) {
        TreeNode* p = newExpNode(OpK);
        if (p != NULL) {
            p->attr.op = token;
            tail = p;
            match(token);
        }
    }
    TreeNode* t = tail;
    while (token == BNOT) {
        TreeNode* p= newExpNode(OpK);
        if (p != NULL) {
            p->attr.op = token;
            match(token);
            p->child[0] = t;
            t = p;
        }
    }
    TreeNode* h = pow_term();
    if (tail) tail->child[0] = h;
    else t = h;
    return t;
}

TreeNode * simple_exp(void)
{ TreeNode * t = term();
  while ((token==PLUS)||(token==MINUS))
  { TreeNode * p = newExpNode(OpK);
    if (p!=NULL) {
      p->child[0] = t;
      p->attr.op = token;
      t = p;
      match(token);
      t->child[1] = term();
    }
  }
  return t;
}

TreeNode * term(void)
{ TreeNode * t = bnot_exp();
  while ((token==TIMES)||(token==OVER)||(token ==MOD))
  { TreeNode * p = newExpNode(OpK);
    if (p!=NULL) {
      p->child[0] = t;
      p->attr.op = token;
      t = p;
      match(token);
      p->child[1] = bnot_exp();
    }
  }
  return t;
}

TreeNode * factor(void)
{ TreeNode * t = NULL;
  switch (token) {
    case NUM :
      t = newExpNode(ConstK);
      if ((t!=NULL) && (token==NUM))
        t->attr.val = atoi(tokenString);
      match(NUM);
      break;
    case ID :
      t = newExpNode(IdK);
      if ((t!=NULL) && (token==ID))
        t->attr.name = copyString(tokenString);
      match(ID);
      break;
    case LPAREN :
      match(LPAREN);
      t = exp();
      match(RPAREN);
      break;
    default:
      syntaxError("unexpected token -> ");
      printToken(token,tokenString);
      token = getToken();
      break;
    }
  return t;
}



static TreeNode* reg(void) {
    TreeNode* t = reg_or();
    while (token == ROR)
    {
        TreeNode* p = newExpNode(OpK);
        if (p != NULL)
        {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
            match(token);
            if (t != NULL) t->child[1] = reg_or();
        }
    }
    return t;
}

static TreeNode* reg_or(void) {
    TreeNode* t = reg_and();
    while(token == RAND) {
        TreeNode* p = newExpNode(OpK);
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
        }
        match(token);
        if (t != NULL)
            t->child[1] = reg_and();
    }
    return t;
}

static TreeNode* reg_and(void) {
    TreeNode* t = reg_base();
    if ((token == RCLOSURE) || (token == RCHOICE))
    {
        TreeNode* p = newExpNode(OpK);
        if (p != NULL)
        {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
            match(token);
        }
    }
    return t;
}

static TreeNode* reg_base(void) {
    TreeNode* t = NULL;
    switch (token)
    {
    case LPAREN:
        match(LPAREN);
        t = reg();
        match(RPAREN);
        break;
    case ID:
        t = newExpNode(IdK);
        if ((t != NULL) && (token == ID))
            t->attr.name = copyString(tokenString);
        match(ID);
        break;
    case NUM:
        t = newExpNode(ConstK);
        if ((t != NULL) && token == NUM)
            t->attr.val = atoi(tokenString);
        match(NUM);
        break;
    default:
        syntaxError("unexpected token -> ");
        printToken(token, tokenString);
        token = getToken();
        break;
    }
    return t;
}




/****************************************/
/* the primary function of the parser   */
/****************************************/
/* Function parse returns the newly 
 * constructed syntax tree
 */
TreeNode * parse(void)
{ TreeNode * t;
  token = getToken();
  t = stmt_sequence();
  if (token!=ENDFILE)
    syntaxError("Code ends before file\n");
  return t;
}
