#include "tinyanalyzor.h"
#include "ui_tinyanalyzor.h"
#include <QFileDialog>
#include <QDebug>
#include <QFile>
#include <QTextStream>


TinyAnalyzor::TinyAnalyzor(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TinyAnalyzor)
{
    ui->setupUi(this);
}

TinyAnalyzor::~TinyAnalyzor()
{
    delete ui;
}


void TinyAnalyzor::on_btn_select_clicked()
{
    QString Qfilename = QFileDialog::getOpenFileName(NULL,"选择文件","/","所有文件(*)");
    if(!Qfilename.isEmpty()){
        ui->fileLabel->setText(Qfilename);
        qDebug()<<"选择文件"<<Qfilename<<endl;
    }
    QFile file(Qfilename);
    QTextStream fileStream(&file);
    QString s;
    if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
        this->filename = Qfilename;
        while(!fileStream.atEnd()){
            s = fileStream.readLine();
            ui->SourceList->addItem(s);
        }
    }
}

void TinyAnalyzor::on_btn_analyze_clicked()
{
    TreeNode * syntaxTree;
    QString filePath =  QDir::currentPath() + "/res.txt";
    qDebug()<<"输出文件路径为："<<filePath<<endl;

    listing = fopen(filePath.toStdString().c_str(),"w");
    source = fopen(this->filename.toStdString().c_str(),"r");
    syntaxTree = parse();
    if(TraceParse){
        fprintf(listing,"Syntax tree:\n");
        printTree(syntaxTree);
        fclose(listing);listing = nullptr;
        QFile file(filePath);
        QTextStream fileStream(&file);
        QString s;
        if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
            while(!fileStream.atEnd()){
                s = fileStream.readLine();
                ui->TargetList->addItem(s);
            }
        }
        fclose(source);source = nullptr;
    }else{
        qDebug()<<"当前文件没有打开，无法写入"<<endl;
    }
}

