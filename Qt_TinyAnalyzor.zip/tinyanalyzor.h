#ifndef TINYANALYZOR_H
#define TINYANALYZOR_H

#include <QMainWindow>
#include <stdio.h>
#include "globals.h"
#include "util.h"
#include "parse.h"

QT_BEGIN_NAMESPACE
namespace Ui { class TinyAnalyzor; }
QT_END_NAMESPACE

class TinyAnalyzor : public QMainWindow
{
    Q_OBJECT

public:
    TinyAnalyzor(QWidget *parent = nullptr);
    ~TinyAnalyzor();

private slots:
    void on_btn_select_clicked();

    void on_btn_analyze_clicked();

private:
    QString filename;
    Ui::TinyAnalyzor *ui;
};
#endif // TINYANALYZOR_H
